# DESCRIPTION:

Sets hostname and FQDN of the node.

# ATTRIBUTES:

set_fqdn - FQDN to set

The latest code is hosted at https://github.com/3ofcoins/chef-cookbook-hostname
