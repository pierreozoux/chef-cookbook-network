maintainer       "Pierre Ozoux"
maintainer_email "pierre.ozoux@gmail.com"
license          "TweetWare"
description      "Configures static-ip"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
