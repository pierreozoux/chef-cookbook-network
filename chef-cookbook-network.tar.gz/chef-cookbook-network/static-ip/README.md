Description
===========

Set the desired static IP to the node.

Requirements
============

Attributes
==========

set_ip - IP to set
set_gateway - gateway to set
set_netmask - netmask to set

Usage
=====

Set the attributes in your JSON attributes file.
